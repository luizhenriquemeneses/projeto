package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Bean.DisciplinasBEAN;

public class DisciplinaDAO {
    ConnectionFactory con;
    public boolean create(DisciplinasBEAN a)throws Exception{
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        
        try {
            stnt = con.prepareStatement("INSERT INTO Disciplinas VALUES(?,?,?,?,?,?,?)");
            
            
            stnt.setInt(1,a.getIddisc());
            stnt.setInt(2,a.getIdcurso());
            stnt.setString(3,a.getCurso());
            stnt.setString(4,a.getNome_disc());
            stnt.setString(5,a.getRequisitos());
            stnt.setString(6,a.getDescricao());
            stnt.setFloat(7,a.getValor());
            
           
            stnt.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Salvar!"+ex);
        }finally{
        ConnectionFactory.closeConnection(con,stnt);
    }
        if(stnt.executeUpdate()>0)
           return true;
           else
           return false;
    }
    
     public DisciplinasBEAN Pesquisar(String nome) throws Exception{
       con = new ConnectionFactory();
       
       DisciplinasBEAN objDisc = null;
       String SQL = "select * from Disciplinas where nome LIKE %nome_disc%";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       ps.setString(1,"%"+nome+"%");
       ResultSet rs = ps.executeQuery();
       while(rs.next()){
           
           objDisc = new DisciplinasBEAN();
           
           objDisc.setIddisc(rs.getInt("iddisc"));
           objDisc.setIdcurso(rs.getInt("idcurso"));
           objDisc.setCurso(rs.getString("curso"));
           objDisc.setNome_disc(rs.getString("nome_disc"));
           objDisc.setRequisitos(rs.getString("requisitos"));
           objDisc.setDescricao(rs.getString("descricao"));
           objDisc.setValor(rs.getFloat("valor"));
           
           
           
       }
       return objDisc;
   }
   
   
   public boolean Editar(DisciplinasBEAN objDisc) throws Exception{
       con = new ConnectionFactory();
       String SQL = "update Disciplinas set iddisc = ?, idcurso = ?,  curso = ?, nome_disc = ? , requisitos = ? , descricao = ? , valor = ?";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       ps.setInt(1, objDisc.getIddisc());
       ps.setInt(2, objDisc.getIdcurso()); 
       ps.setString(3, objDisc.getCurso());
       ps.setString(4, objDisc.getNome_disc());
       ps.setString(5, objDisc.getRequisitos());
       ps.setString(6, objDisc.getDescricao());
       ps.setFloat(7, objDisc.getValor());
       
       if(ps.executeUpdate()>0)
           return true;
           else
           return false;
   }
   public boolean Excluir(int id_disc)throws Exception{
       con = new ConnectionFactory();
       String SQL = "delete from Disciplinas where iddisc = ?";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       ps.setInt(1, id_disc);
       if(ps.executeUpdate()>0)
           return true;
           else
           return false;
   

   }
   public List<DisciplinasBEAN> read(){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        ResultSet rs = null;
        
        List<DisciplinasBEAN> disciplinas = new ArrayList<DisciplinasBEAN>();
        
        try {
            stnt = con.prepareStatement("select*from Disciplinas");
            rs = stnt.executeQuery();
            
            while(rs.next()){
                
               DisciplinasBEAN disciplina = new DisciplinasBEAN();
                
                disciplina.setIddisc(rs.getInt("iddisc"));
                disciplina.setIdcurso(rs.getInt("idcurso"));
                disciplina.setCurso(rs.getString("curso"));
                disciplina.setNome_disc(rs.getString("nome_disc"));
                disciplina.setRequisitos(rs.getString("requisitos"));
                disciplina.setDescricao(rs.getString("descricao"));
                disciplina.setValor(rs.getFloat("valor"));
               
                disciplinas.add(disciplina);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stnt, rs);
        }
        
        return disciplinas;
    }
   
   public List<DisciplinasBEAN> readBuscar(String nome){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        ResultSet rs = null;
        
        List<DisciplinasBEAN> disciplinas = new ArrayList<DisciplinasBEAN>();
        
        try {
            stnt = con.prepareStatement("select*from Disciplinas where nome_disc LIKE %nome_disc%?");
            stnt.setString(1,"%"+nome+"%");
            rs = stnt.executeQuery();
            
            while(rs.next()){
                
                DisciplinasBEAN disciplina = new DisciplinasBEAN();
                
                disciplina.setIddisc(rs.getInt("iddisc"));
                disciplina.setIdcurso(rs.getInt("idcurso"));
                disciplina.setCurso(rs.getString("curso"));
                disciplina.setNome_disc(rs.getString("nome_disc"));
                disciplina.setRequisitos(rs.getString("requisitos"));
                disciplina.setDescricao(rs.getString("descricao"));
                disciplina.setValor(rs.getFloat("valor"));
                
                
                disciplinas.add(disciplina);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stnt, rs);
        }
        
        return disciplinas;
    }
   
}
