package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Bean.CursosBEAN;

public class CursoDAO {
    ConnectionFactory con;
    public boolean create(CursosBEAN a)throws Exception{
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        
        try {
            stnt = con.prepareStatement("INSERT INTO Cursos VALUES(?,?,?,?,?,?)");
            stnt.setInt(1,a.getIdcurso());
            stnt.setInt(2,a.getIdfunc());
            stnt.setString(3,a.getNome_func());
            stnt.setString(4,a.getNome_curso());
            stnt.setString(5,a.getDescricao());
            stnt.setString(6,a.getRequisitos());
            
            stnt.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Salvar!"+ex);
        }finally{
        ConnectionFactory.closeConnection(con,stnt);
    }
        if(stnt.executeUpdate()>0)
           return true;
           else
           return false;
    }
    
     public CursosBEAN Pesquisar(String nome) throws Exception{
       con = new ConnectionFactory();
       
       CursosBEAN objCurso = null;
       String SQL = "select * from Cursos where Nome_curso LIKE %nome_curso%";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       ps.setString(1,"%"+nome+"%");
       ResultSet rs = ps.executeQuery();
       while(rs.next()){
           objCurso = new CursosBEAN();
           
            objCurso.setIdcurso(rs.getInt("idcurso"));
            objCurso.setIdfunc(rs.getInt("idfunc"));
            objCurso.setNome_func(rs.getString("nome_func"));
            objCurso.setNome_curso(rs.getString("nome_curso"));
            objCurso.setDescricao(rs.getString("descricao"));
            objCurso.setRequisitos(rs.getString("requisitos"));
            objCurso.setNome_curso(rs.getString("Nome_curso"));
            
           
       }
       return objCurso;
   }
   
   
   public boolean Editar(CursosBEAN objCurso) throws Exception{
       con = new ConnectionFactory();
       String SQL = "update Cursos set idcurso = ?, id_func = ?, nome_func = ?, nome_curso = ?,descicao = ?, requisitos = ?";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       
            ps.setInt(1,objCurso.getIdcurso());
            ps.setInt(2,objCurso.getIdfunc());
            ps.setString(3,objCurso.getNome_func());
            ps.setString(4,objCurso.getNome_curso());
            ps.setString(5,objCurso.getDescricao());
            ps.setString(6,objCurso.getRequisitos());
      
       
       if(ps.executeUpdate()>0)
           return true;
           else
           return false;
   }
   public boolean Excluir(int id_curso)throws Exception{
       con = new ConnectionFactory();
       String SQL = "delete from Cursos where idcurso = ?";
       PreparedStatement ps = con.getConnection().prepareStatement(SQL);
       ps.setInt(1, id_curso);
       if(ps.executeUpdate()>0)
           return true;
           else
           return false;
   

   }
   public List<CursosBEAN> read(){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        ResultSet rs = null;
        
        List<CursosBEAN> cursos = new ArrayList<CursosBEAN>();
        
        try {
            stnt = con.prepareStatement("select*from Cursos");
            rs = stnt.executeQuery();
            
            while(rs.next()){
                
                CursosBEAN curso = new CursosBEAN();
                
            curso.setIdcurso(rs.getInt("idcurso"));
            curso.setIdfunc(rs.getInt("idfunc"));
            curso.setNome_func(rs.getString("nome_func"));
            curso.setNome_curso(rs.getString("nome_curso"));
            curso.setDescricao(rs.getString("descricao"));
            curso.setRequisitos(rs.getString("requisitos"));
            curso.setNome_curso(rs.getString("Nome_curso"));
                
               
                
                cursos.add(curso);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stnt, rs);
        }
        
        return cursos;
    }
   
   public List<CursosBEAN> readBuscar(String nome){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stnt = null;
        ResultSet rs = null;
        
        List<CursosBEAN> cursos = new ArrayList<CursosBEAN>();
        
        try {
            stnt = con.prepareStatement("select*from Cursos where Nome_curso LIKE ?");
            stnt.setString(1,"%"+nome+"%");
            rs = stnt.executeQuery();
            
            while(rs.next()){
                
                CursosBEAN curso = new CursosBEAN();
                
            curso.setIdcurso(rs.getInt("idcurso"));
            curso.setIdfunc(rs.getInt("idfunc"));
            curso.setNome_func(rs.getString("nome_func"));
            curso.setNome_curso(rs.getString("nome_curso"));
            curso.setDescricao(rs.getString("descricao"));
            curso.setRequisitos(rs.getString("requisitos"));
            curso.setNome_curso(rs.getString("Nome_curso"));
                
                
                
                cursos.add(curso);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stnt, rs);
        }
        
        return cursos;
    }
   
}
