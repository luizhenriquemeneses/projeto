
package model.Bean;


public class TurmaBEAN {
    
    private int idturma;
    private int idmatricula;
    private String data_matricula;
    private int idaluno;
    private String nome_aluno;
    private int idcurso;
    private String nome_curso;       
    private int iddisc1;
    private int iddisc2;
    private int iddisc3;
    private int iddisc4;
    private int iddisc5;
    private String disciplina1;
    private String disciplina2;
    private String disciplina3;
    private String disciplina4;
    private String disciplina5;
    private String horarios;
    private int limitevagas;

    public int getIdturma() {
        return idturma;
    }

    public void setIdturma(int idturma) {
        this.idturma = idturma;
    }

    public int getIdmatricula() {
        return idmatricula;
    }

    public void setIdmatricula(int idmatricula) {
        this.idmatricula = idmatricula;
    }

    public String getData_matricula() {
        return data_matricula;
    }

    public void setData_matricula(String data_matricula) {
        this.data_matricula = data_matricula;
    }

    public int getIdaluno() {
        return idaluno;
    }

    public void setIdaluno(int idaluno) {
        this.idaluno = idaluno;
    }

    public String getNome_aluno() {
        return nome_aluno;
    }

    public void setNome_aluno(String nome_aluno) {
        this.nome_aluno = nome_aluno;
    }

    public int getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(int idcurso) {
        this.idcurso = idcurso;
    }

    public String getNome_curso() {
        return nome_curso;
    }

    public void setNome_curso(String nome_curso) {
        this.nome_curso = nome_curso;
    }

    public int getIddisc1() {
        return iddisc1;
    }

    public void setIddisc1(int iddisc1) {
        this.iddisc1 = iddisc1;
    }

    public int getIddisc2() {
        return iddisc2;
    }

    public void setIddisc2(int iddisc2) {
        this.iddisc2 = iddisc2;
    }

    public int getIddisc3() {
        return iddisc3;
    }

    public void setIddisc3(int iddisc3) {
        this.iddisc3 = iddisc3;
    }

    public int getIddisc4() {
        return iddisc4;
    }

    public void setIddisc4(int iddisc4) {
        this.iddisc4 = iddisc4;
    }

    public int getIddisc5() {
        return iddisc5;
    }

    public void setIddisc5(int iddisc5) {
        this.iddisc5 = iddisc5;
    }

    public String getDisciplina1() {
        return disciplina1;
    }

    public void setDisciplina1(String disciplina1) {
        this.disciplina1 = disciplina1;
    }

    public String getDisciplina2() {
        return disciplina2;
    }

    public void setDisciplina2(String disciplina2) {
        this.disciplina2 = disciplina2;
    }

    public String getDisciplina3() {
        return disciplina3;
    }

    public void setDisciplina3(String disciplina3) {
        this.disciplina3 = disciplina3;
    }

    public String getDisciplina4() {
        return disciplina4;
    }

    public void setDisciplina4(String discplina4) {
        this.disciplina4 = discplina4;
    }

    public String getDisciplina5() {
        return disciplina5;
    }

    public void setDisciplina5(String disciplina5) {
        this.disciplina5 = disciplina5;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public int getLimitevagas() {
        return limitevagas;
    }

    public void setLimitevagas(int limitevagas) {
        this.limitevagas = limitevagas;
    }
 
    
}